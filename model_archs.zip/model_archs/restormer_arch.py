## Restormer: Efficient Transformer for High-Resolution Image Restoration
## Syed Waqas Zamir, Aditya Arora, Salman Khan, Munawar Hayat, Fahad Shahbaz Khan, and Ming-Hsuan Yang
## https://arxiv.org/abs/2111.09881


import numpy as np
from PIL import Image
import torch
import cv2

from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

import torch
import torch.nn as nn
import torch.nn.functional as F
from pdb import set_trace as stx
import numbers

from einops import rearrange
from thop import profile

from copy import deepcopy


##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)

class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma+1e-5) * self.weight

class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma+1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

# def show_feature_map(feature_map):  # feature_map=torch.Size([1, 64, 55, 55]),feature_map[0].shape=torch.Size([64, 55, 55])
#     # feature_map[2].shape     out of bounds
#     # feature_map = feature_map.detach().numpy().squeeze()  # 压缩成torch.Size([64, 55, 55])
#     # feature_map_num = feature_map.shape[0]  # 返回通道数
    
#     # for index in range(feature_map_num):  # 通过遍历的方式，将64个通道的tensor拿出
#     #     feature=feature_map[index]
#     #     feature = np.asarray(feature* 255, dtype=np.uint8)
#     #     feature=cv2.resize(feature,(256,256),interpolation =  cv2.INTER_NEAREST) #改变特征呢图尺寸
#     #     feature = cv2.applyColorMap(feature, cv2.COLORMAP_JET) #变成伪彩图
#     #     cv2.imwrite('./GMSFL/3/channel_{}.png'.format(str(index)), feature)

#     features = feature_map.squeeze(0)  # [180, 64, 64]
#     features_reshaped = features.view(180, -1)  # [180, 4096]
#     features_np = features_reshaped.cpu().numpy().T  # [4096, 180]
    
#     # 2. 数据标准化（零均值标准化）
#     scaler = StandardScaler()
#     features_scaled = scaler.fit_transform(features_np)
    
#     # 3. 应用PCA降维到3通道
#     pca = PCA(n_components=3)
#     rgb_features = pca.fit_transform(features_scaled)
    
#     # 4. 将降维后的数据重新整形为图像格式 [64, 64, 3]
#     rgb_image = rgb_features.reshape(64, 64, 3)

#     for index in range(3):  # 通过遍历的方式，将64个通道的tensor拿出
#         feature=rgb_image[index]
#         feature = np.asarray(feature* 255, dtype=np.uint8)
#         feature=cv2.resize(feature,(256,256),interpolation =  cv2.INTER_NEAREST) #改变特征呢图尺寸
#         feature = cv2.applyColorMap(feature, cv2.COLORMAP_JET) #变成伪彩图
#         cv2.imwrite('./GMSFL/3/channel_{}.png'.format(str(index)), feature)


##########################################################################
## Gated-Dconv Feed-Forward Network (GDFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x
    
class GDFMFL(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(GDFMFL, self).__init__()
        
        hidden_features_g = int(dim*ffn_expansion_factor)
        hidden_features = 180

        self.project_in_g = nn.Conv2d(dim, hidden_features_g*2, kernel_size=1, bias=bias)
        
        self.project_in = nn.Conv2d(dim, hidden_features, kernel_size=1, bias=bias)
        
        self.dwconv_g = nn.Conv2d(hidden_features_g*2, hidden_features_g*2, kernel_size=3, stride=1, padding=1, groups=hidden_features_g*2, bias=bias)

        self.dwconv3x3 = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1, groups=hidden_features, bias=bias)
        self.dwconv5x5 = nn.Conv2d(hidden_features, hidden_features, kernel_size=5, stride=1, padding=2, groups=hidden_features, bias=bias)
        self.dwconv7x7 = nn.Conv2d(hidden_features, hidden_features, kernel_size=7, stride=1, padding=3, groups=hidden_features, bias=bias)

        self.relu3 = nn.ReLU()
        self.relu5 = nn.ReLU()
        self.relu7 = nn.ReLU()

        # self.dwconv3x3_1 = nn.Conv2d(hidden_features, 3, kernel_size=3, bias=bias)
        # self.dwconv5x5_1 = nn.Conv2d(hidden_features, 3, kernel_size=5, bias=bias)
        # self.dwconv7x7_1 = nn.Conv2d(hidden_features, 3, kernel_size=7, bias=bias)


#         self.relu3_1 = nn.ReLU()
#         self.relu5_1 = nn.ReLU()
#         self.relu7_1 = nn.ReLU()

        self.project_out_g = nn.Conv2d(hidden_features_g * 2, dim, kernel_size=1, bias=bias)
        self.project_out = nn.Conv2d(hidden_features * 3, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        
        x_g = x
        #x_g  = x_g.reshape(b, c, h, w)
        x = self.project_in(x)
        x_g = self.project_in_g(x_g)
        
        x_g = self.dwconv_g(x_g)
        
        x1 = self.relu3(self.dwconv3x3(x))
        x2 = self.relu5(self.dwconv5x5(x))
        x3 = self.relu7(self.dwconv7x7(x))

#         x1 = torch.cat([x1_3, x1_5, x1_7], dim=1)
#         x2 = torch.cat([x2_3, x2_5, x2_7], dim=1)
#         x3 = torch.cat([x3_3, x3_5, x3_7], dim=1)  #

#         x1 = self.relu3_1(self.dwconv3x3_1(x1))
#         x2 = self.relu5_1(self.dwconv5x5_1(x2))
#         x3 = self.relu7_1(self.dwconv7x7_1(x3))

        x = torch.cat([x1, x2, x3], dim=1)
        x = self.project_out(x)
        
        x_g = F.gelu(x_g)
        x_g = self.project_out_g(x_g)
        #x_g = x_g.reshape(b, h * w, c)
        #x_g = self.project_out_g(x_g)
        
        x = x_g * x
            
        return x

class MFL1(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(MFL1, self).__init__()
        
        hidden_features_g = int(dim*ffn_expansion_factor)
        hidden_features = 180


        
        self.project_in = nn.Conv2d(dim, hidden_features, kernel_size=1, bias=bias)
        
 

        #self.dwconv3x3 = nn.Conv2d(hidden_features, hidden_features, kernel_size=3, stride=1, padding=1, groups=hidden_features, bias=bias)
        #self.dwconv5x5 = nn.Conv2d(hidden_features, hidden_features, kernel_size=5, stride=1, padding=2, groups=hidden_features, bias=bias)
        self.dwconv7x7 = nn.Conv2d(hidden_features, hidden_features, kernel_size=7, stride=1, padding=3, groups=hidden_features, bias=bias)

        #self.relu3 = nn.ReLU()
        #self.relu5 = nn.ReLU()
        self.relu7 = nn.ReLU()


        self.project_out = nn.Conv2d(hidden_features * 3, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        

        x = self.project_in(x)

        
        
        x1 = self.relu7(self.dwconv7x7(x))
        x2 = self.relu7(self.dwconv7x7(x))
        x3 = self.relu7(self.dwconv7x7(x))
        #x2 = self.relu5(self.dwconv5x5(x))
        #x3 = self.relu7(self.dwconv7x7(x))

        x = torch.cat([x1, x2, x3], dim=1)
        x = self.project_out(x)
        
        #x_g = F.gelu(x_g)
        #x_g = self.project_out_g(x_g)
        #x_g = x_g.reshape(b, h * w, c)
        #x_g = self.project_out_g(x_g)
        
        #x = x_g * x
            
        return x


##########################################################################
## Multi-DConv Head Transposed Self-Attention (MDTA)
class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim*3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        


    def forward(self, x):
        b,c,h,w = x.shape

        qkv = self.qkv_dwconv(self.qkv(x))
        q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out)
        return out



##########################################################################
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias, LayerNorm_type):
        super(TransformerBlock, self).__init__()

        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))

        return x



##########################################################################
## Overlapped image patch embedding with 3x3 Conv
class OverlapPatchEmbed(nn.Module):
    def __init__(self, in_c=3, embed_dim=48, bias=False):
        super(OverlapPatchEmbed, self).__init__()

        self.proj = nn.Conv2d(in_c, embed_dim, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, x):
        x = self.proj(x)

        return x



##########################################################################
## Resizing modules
class Downsample(nn.Module):
    def __init__(self, n_feat):
        super(Downsample, self).__init__()

        self.body = nn.Sequential(nn.Conv2d(n_feat, n_feat//2, kernel_size=3, stride=1, padding=1, bias=False),
                                  nn.PixelUnshuffle(2))

    def forward(self, x):
        return self.body(x)

class Upsample(nn.Module):
    def __init__(self, n_feat):
        super(Upsample, self).__init__()

        self.body = nn.Sequential(nn.Conv2d(n_feat, n_feat*2, kernel_size=3, stride=1, padding=1, bias=False),
                                  nn.PixelShuffle(2))

    def forward(self, x):
        return self.body(x)

##########################################################################
##---------- Restormer -----------------------
class Restormer(nn.Module):
    def __init__(self, 
        inp_channels=3, 
        out_channels=3, 
        dim = 48,
        num_blocks = [4,6,6,8], 
        num_refinement_blocks = 4,
        heads = [1,2,4,8],
        ffn_expansion_factor = 2.66,
        bias = False,
        LayerNorm_type = 'WithBias',   ## Other option 'BiasFree'
        dual_pixel_task = False        ## True for dual-pixel defocus deblurring only. Also set inp_channels=6
    ):

        super(Restormer, self).__init__()

        self.patch_embed = OverlapPatchEmbed(inp_channels, dim)

        self.encoder_level1 = nn.Sequential(*[TransformerBlock(dim=dim, num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[0])])
        
        self.down1_2 = Downsample(dim) ## From Level 1 to Level 2
        self.encoder_level2 = nn.Sequential(*[TransformerBlock(dim=int(dim*2**1), num_heads=heads[1], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[1])])
        
        self.down2_3 = Downsample(int(dim*2**1)) ## From Level 2 to Level 3
        self.encoder_level3 = nn.Sequential(*[TransformerBlock(dim=int(dim*2**2), num_heads=heads[2], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[2])])

        self.down3_4 = Downsample(int(dim*2**2)) ## From Level 3 to Level 4
        self.latent = nn.Sequential(*[TransformerBlock(dim=int(dim*2**3), num_heads=heads[3], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[3])])
        
        self.up4_3 = Upsample(int(dim*2**3)) ## From Level 4 to Level 3
        self.reduce_chan_level3 = nn.Conv2d(int(dim*2**3), int(dim*2**2), kernel_size=1, bias=bias)
        self.decoder_level3 = nn.Sequential(*[TransformerBlock(dim=int(dim*2**2), num_heads=heads[2], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[2])])


        self.up3_2 = Upsample(int(dim*2**2)) ## From Level 3 to Level 2
        self.reduce_chan_level2 = nn.Conv2d(int(dim*2**2), int(dim*2**1), kernel_size=1, bias=bias)
        self.decoder_level2 = nn.Sequential(*[TransformerBlock(dim=int(dim*2**1), num_heads=heads[1], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[1])])
        
        self.up2_1 = Upsample(int(dim*2**1))  ## From Level 2 to Level 1  (NO 1x1 conv to reduce channels)

        self.decoder_level1 = nn.Sequential(*[TransformerBlock(dim=int(dim*2**1), num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_blocks[0])])
        
        self.refinement = nn.Sequential(*[TransformerBlock(dim=int(dim*2**1), num_heads=heads[0], ffn_expansion_factor=ffn_expansion_factor, bias=bias, LayerNorm_type=LayerNorm_type) for i in range(num_refinement_blocks)])
        
        #### For Dual-Pixel Defocus Deblurring Task ####
        self.dual_pixel_task = dual_pixel_task
        if self.dual_pixel_task:
            self.skip_conv = nn.Conv2d(dim, int(dim*2**1), kernel_size=1, bias=bias)
        ###########################
            
        self.output = nn.Conv2d(int(dim*2**1), out_channels, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, inp_img):

        inp_enc_level1 = self.patch_embed(inp_img)
        out_enc_level1 = self.encoder_level1(inp_enc_level1)
        
        inp_enc_level2 = self.down1_2(out_enc_level1)
        out_enc_level2 = self.encoder_level2(inp_enc_level2)

        inp_enc_level3 = self.down2_3(out_enc_level2)
        out_enc_level3 = self.encoder_level3(inp_enc_level3) 

        inp_enc_level4 = self.down3_4(out_enc_level3)        
        latent = self.latent(inp_enc_level4) 
                        
        inp_dec_level3 = self.up4_3(latent)
        inp_dec_level3 = torch.cat([inp_dec_level3, out_enc_level3], 1)
        inp_dec_level3 = self.reduce_chan_level3(inp_dec_level3)
        out_dec_level3 = self.decoder_level3(inp_dec_level3) 

        inp_dec_level2 = self.up3_2(out_dec_level3)
        inp_dec_level2 = torch.cat([inp_dec_level2, out_enc_level2], 1)
        inp_dec_level2 = self.reduce_chan_level2(inp_dec_level2)
        out_dec_level2 = self.decoder_level2(inp_dec_level2) 

        inp_dec_level1 = self.up2_1(out_dec_level2)
        inp_dec_level1 = torch.cat([inp_dec_level1, out_enc_level1], 1)
        out_dec_level1 = self.decoder_level1(inp_dec_level1)
        
        out_dec_level1 = self.refinement(out_dec_level1)

        #### For Dual-Pixel Defocus Deblurring Task ####
        if self.dual_pixel_task:
            out_dec_level1 = out_dec_level1 + self.skip_conv(inp_enc_level1)
            out_dec_level1 = self.output(out_dec_level1)
        ###########################
        else:
            out_dec_level1 = self.output(out_dec_level1) + inp_img


        return out_dec_level1
    
    
def print_network(net):
    num_params = 0
    for param in net.parameters():
        num_params += param.numel()
    print(net)
    print('Total number of parameters: %f M' % (num_params / 1e6))


# def show_feature_map(feature_map):  # feature_map=torch.Size([1, 64, 55, 55]),feature_map[0].shape=torch.Size([64, 55, 55])
#     # feature_map[2].shape     out of bounds
#     feature_map = feature_map.detach().numpy().squeeze()  # 压缩成torch.Size([64, 55, 55])
#     feature_map_num = feature_map.shape[0]  # 返回通道数
 
#     for index in range(feature_map_num):  # 通过遍历的方式，将64个通道的tensor拿出
#         feature=feature_map[index]
#         feature = np.asarray(feature* 255, dtype=np.uint8)
#         feature=cv2.resize(feature,(224,224),interpolation =  cv2.INTER_NEAREST) #改变特征呢图尺寸
#         feature = cv2.applyColorMap(feature, cv2.COLORMAP_JET) #变成伪彩图
#         cv2.imwrite('/home/cai/project/Catheter/Data/feature_map_save/channel_{}.png'.format(str(index)), feature)



if __name__ == '__main__':
    input = torch.rand(1, 180, 128, 128).cuda()  # B C H W
    #model = Restormer().cuda()
    model = GDFMFL(180,2.66,False).cuda()
    flops, params = profile(model, inputs=(input,))
    # print_network(model)
    print("Param: {} M".format(params/1e6))
    print("FLOPs: {} G".format(flops/1e9))
    
    #output = model(input)
    #print(output.size())