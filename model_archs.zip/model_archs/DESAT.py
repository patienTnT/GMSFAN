import torch.nn as nn
import torch
from basicsr.archs.arch_util import to_2tuple, trunc_normal_
import math
from thop import profile
import math
import torch.nn.functional as F
from collections import OrderedDict
import sys
from torch.nn import init
import numpy as np

import math
import torch.utils.checkpoint as checkpoint
from basicsr.utils.registry import ARCH_REGISTRY
from basicsr.archs.arch_util import to_2tuple, trunc_normal_
from einops import rearrange


def drop_path(x, drop_prob: float = 0., training: bool = False):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks).

    From: https://github.com/rwightman/pytorch-image-models/blob/master/timm/models/layers/drop.py
    """
    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0], ) + (1, ) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output


class DropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).

    From: https://github.com/rwightman/pytorch-image-models/blob/master/timm/models/layers/drop.py
    """

    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path(x, self.drop_prob, self.training)


class ChannelAttention(nn.Module):
    """Channel attention used in RCAN.
    Args:
        num_feat (int): Channel number of intermediate features.
        squeeze_factor (int): Channel squeeze factor. Default: 16.
    """

    def __init__(self, num_feat, squeeze_factor=16):
        super(ChannelAttention, self).__init__()
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(num_feat, num_feat // squeeze_factor, 1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_feat // squeeze_factor, num_feat, 1, padding=0),
            nn.Sigmoid())

    def forward(self, x):
        y = self.attention(x)
        return x * y


class CAB(nn.Module):

    def __init__(self, num_feat, compress_ratio=3, squeeze_factor=30):
        super(CAB, self).__init__()

        self.cab = nn.Sequential(
            nn.Conv2d(num_feat, num_feat // compress_ratio, 3, 1, 1),
            nn.GELU(),
            nn.Conv2d(num_feat // compress_ratio, num_feat, 3, 1, 1),
            ChannelAttention(num_feat, squeeze_factor)
            )

    def forward(self, x):
        return self.cab(x)


class Mlp(nn.Module):

    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


def window_partition(x, window_size):
    """
    Args:
        x: (b, h, w, c)
        window_size (int): window size

    Returns:
        windows: (num_windows*b, window_size, window_size, c)
    """
    b, h, w, c = x.shape
    x = x.view(b, h // window_size, window_size, w // window_size, window_size, c)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, c)
    return windows


def window_reverse(windows, window_size, h, w):
    """
    Args:
        windows: (num_windows*b, window_size, window_size, c)
        window_size (int): Window size
        h (int): Height of image
        w (int): Width of image

    Returns:
        x: (b, h, w, c)
    """
    b = int(windows.shape[0] / (h * w / window_size / window_size))
    x = windows.view(b, h // window_size, w // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(b, h, w, -1)
    return x


class WindowAttention(nn.Module):
    r""" Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.

    Args:
        dim (int): Number of input channels.
        window_size (tuple[int]): The height and width of the window.
        num_heads (int): Number of attention heads.
        qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set
        attn_drop (float, optional): Dropout ratio of attention weight. Default: 0.0
        proj_drop (float, optional): Dropout ratio of output. Default: 0.0
    """

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0.):

        super().__init__()
        self.dim = dim
        self.window_size = window_size  # Wh, Ww
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim**-0.5

        # define a parameter table of relative position bias
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads))  # 2*Wh-1 * 2*Ww-1, nH

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)

        self.proj_drop = nn.Dropout(proj_drop)

        trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, rpi, mask=None):
        """
        Args:
            x: input features with shape of (num_windows*b, n, c)
            mask: (0/-inf) mask with shape of (num_windows, Wh*Ww, Wh*Ww) or None
        """
        b_, n, c = x.shape
        qkv = self.qkv(x).reshape(b_, n, 3, self.num_heads, c // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # make torchscript happy (cannot use tensor as tuple)

        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))

        relative_position_bias = self.relative_position_bias_table[rpi.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)  # Wh*Ww,Wh*Ww,nH
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # nH, Wh*Ww, Wh*Ww
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            nw = mask.shape[0]
            attn = attn.view(b_ // nw, nw, self.num_heads, n, n) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, n, n)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(b_, n, c)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x
    


class WindowFusion(nn.Module):
    r""" Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.

    Args:
        dim (int): Number of input channels.
        window_size (tuple[int]): The height and width of the window.
        num_heads (int): Number of attention heads.
        qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set
        attn_drop (float, optional): Dropout ratio of attention weight. Default: 0.0
        proj_drop (float, optional): Dropout ratio of output. Default: 0.0
    """

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, qk_scale=None, attn_drop=0., proj_drop=0.):

        super().__init__()
        self.dim = dim
        self.window_size = window_size  # Wh, Ww
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        # define a parameter table of relative position bias
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads))  # 2*Wh-1 * 2*Ww-1, nH

        # get pair-wise relative position index for each token inside the window
        coords_h = torch.arange(self.window_size[0])
        coords_w = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, Wh, Ww
        coords_flatten = torch.flatten(coords, 1)  # 2, Wh*Ww
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh*Ww, Wh*Ww
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # Wh*Ww, Wh*Ww, 2
        relative_coords[:, :, 0] += self.window_size[0] - 1  # shift to start from 0
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # Wh*Ww, Wh*Ww
        self.register_buffer("relative_position_index", relative_position_index)

        self.q = nn.Linear(dim * 2, dim , bias=qkv_bias)
        self.k = nn.Linear(dim, dim, bias=qkv_bias)
        self.v = nn.Linear(dim, dim, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)

        self.proj_drop = nn.Dropout(proj_drop)

        trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x,y, mask=None):
        """
        Args:
            x: input features with shape of (num_windows*B, N, C)
            mask: (0/-inf) mask with shape of (num_windows, Wh*Ww, Wh*Ww) or None
        """
        B_, N, C = x.shape
        q=self.q(y).reshape(B_, N, self.num_heads, C // self.num_heads).permute( 0, 2, 1, 3)
        k=self.k(x).reshape(B_, N, self.num_heads, C // self.num_heads).permute( 0, 2, 1, 3)
        v=self.v(x).reshape(B_, N, self.num_heads, C // self.num_heads).permute( 0, 2, 1, 3)

        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))

        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)  # Wh*Ww,Wh*Ww,nH
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # nH, Wh*Ww, Wh*Ww
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            nW = mask.shape[0]
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

    def extra_repr(self) -> str:
        return f'dim={self.dim}, window_size={self.window_size}, num_heads={self.num_heads}'

    def flops(self, N):
        # calculate flops for 1 window with token length of N
        flops = 0
        flops += N * self.dim * 3 * self.dim
        flops += self.num_heads * N * (self.dim // self.num_heads) * N
        flops += self.num_heads * N * N * (self.dim // self.num_heads)
        flops += N * self.dim * self.dim
        return flops

class DEStripAttention(nn.Module):# This is propoesd distance-enhanced strip attention for each strip window
    def __init__(self,in_features,out_features,x_size,head=4,stride=(16,4), dis_mask=[], alpha=0.3,window_size=(16,4),dimension='H'):
        super(DEStripAttention,self).__init__()
        self.in_features=in_features
        self.hid_features=out_features*3
        self.head=head
        self.stride=stride
        self.window_size=window_size
        self.number=window_size[0]*window_size[1]
        self.dis_mask=dis_mask.view(1,self.number,self.number)
        self.trans=nn.Conv2d(in_channels=self.in_features,out_channels=self.hid_features,kernel_size=1,stride=1,padding=0,bias=False)
        self.unfold=nn.Unfold(kernel_size=window_size,padding=0,stride=self.stride)
        self.fold=nn.Fold(output_size=x_size,kernel_size=window_size,stride=self.stride)
        self.drop=nn.Dropout(0.0)
        self.leakyrelu=nn.LeakyReLU(alpha)
    def forward(self, x):
        self.dis_mask=self.dis_mask.to(x.device)
        x=self.trans(x)
        q,k,v=torch.chunk(x, 3, dim=1)
        b,c,h,w=q.shape
        q=q.reshape(b,self.head,-1,h,w)
        k=k.reshape(b,self.head,-1,h,w)
        v=v.reshape(b,self.head,-1,h,w)
        q=q.reshape(b*self.head,-1,h,w)
        q=self.unfold(q)
        q=q.view(b,self.head,-1,self.number,h//self.stride[0],w//self.stride[1]).permute(0,1,4,5,3,2).contiguous()
        k=k.reshape(b*self.head,-1,h,w)
        k=self.unfold(k)
        k=k.view(b,self.head,-1,self.number,h//self.stride[0],w//self.stride[1]).permute(0,1,4,5,2,3).contiguous()
        v=v.reshape(b*self.head,-1,h,w)
        v=self.unfold(v)
        v=v.view(b,self.head,-1,self.number,h//self.stride[0],w//self.stride[1]).permute(0,1,4,5,3,2).contiguous()

        att=q@k
        att=att/math.sqrt(c//self.head)
        att=att * self.dis_mask
        att=F.softmax(att,dim=-1)
        att=att.view(-1, self.number, self.number)
        
        att=att.view(b, self.head, h//self.stride[0], w//self.stride[1], self.number, self.number)

        att=self.drop(att)
        
        result=att@v 

        result=result.permute(0,1,5,4,2,3).contiguous()
        result=result.view(b,-1,(h//self.stride[0])*(w//self.stride[1]))
        result=self.fold(result)
        return result
    

class DESA(nn.Module): #horizontal or vertical partiion for DESAM
    def __init__(self, in_features,out_features,x_size,head=4,stride=(16,4),dis_mask=[], dimension='H'):
        super(DESA, self).__init__()
        self.gama = nn.Parameter(torch.zeros(1))
        if dimension=='H':
            self.output = nn.Sequential( 
                DEStripAttention(in_features,out_features, x_size, head, stride=(16,4), dis_mask = dis_mask,window_size=(16,4),dimension='H'), 
            )
        else:
            self.output = nn.Sequential( 
                DEStripAttention(in_features,out_features, x_size, head, stride=(4,16), dis_mask = dis_mask,window_size=(4,16),dimension='W'), 
            )
    def forward(self, x):
        return self.output(x)
    

class DESABlock(nn.Module):  #The propose DESAM in paper"DESAT"
    def calculate_mask(self, kernal_size,dimension='H',scale=8):
        if dimension=='H':
            number = 0
            dis_mask=[]
            dis_mask_line=[]
            max_dis = math.sqrt(9 + (kernal_size-1)**2)
            for i in range(0,kernal_size*4):
                l1 = i//4
                c1 = i%4
                # print("x",l1,c1)
                dis_mask_line=[]
                for j in range(0,kernal_size*4):
                    l2 = j//4
                    c2 = j%4
                    # print('H',l1,c1,l2,c2)
                    dis = math.sqrt((c1-c2)*(c1-c2) + (l1-l2)*(l1-l2))
                    # print(dis)
                    dis_mask_line.append(max_dis - dis + 1)
                dis_mask.append(dis_mask_line)
            dis_tensor = torch.tensor(dis_mask, dtype=torch.float32)
            # print("dis_matrix",max_dis, kernal_size, dis_tensor)
            dis_tensor = F.softmax(dis_tensor/scale, dim=1)
            # print("H",dis_tensor.shape,dis_tensor)
        elif dimension=='W':
            number = 0
            dis_mask=[]
            dis_mask_line=[]
            max_dis = math.sqrt(9 + (kernal_size-1)**2)
            for i in range(0,kernal_size*4):
                l1 = i//kernal_size
                c1 = i%kernal_size
                # print("x",l1,c1)
                dis_mask_line=[]
                for j in range(0,kernal_size*4):
                    l2 = j//kernal_size
                    c2 = j%kernal_size
                    # print('W',l1,c1,l2,c2)
                    dis = math.sqrt((c1-c2)*(c1-c2) + (l1-l2)*(l1-l2))
                    # print(dis)
                    dis_mask_line.append(max_dis - dis + 1)
                dis_mask.append(dis_mask_line)
            dis_tensor = torch.tensor(dis_mask, dtype=torch.float32)
            # print("dis_matrix",max_dis, kernal_size, dis_tensor)
            dis_tensor = F.softmax(dis_tensor/scale, dim=1)
            # print("W",dis_tensor.shape,dis_tensor)
        elif dimension=='X':
            number = 0
            dis_mask=[]
            dis_mask_line=[]
            max_dis = (kernal_size-1)
            for i in range(0,kernal_size):
                l1 = i
                c1 = 0
                # print("x",l1,c1)
                dis_mask_line=[]
                for j in range(0,kernal_size):
                    l2 = (i+j)%kernal_size
                    c2 = j
                    dis = math.sqrt((c1-c2)*(c1-c2) + (l1-l2)*(l1-l2))
                    # print(dis)
                    dis_mask_line.append(max_dis - dis + 1)
                dis_mask.append(dis_mask_line)
            dis_tensor = torch.tensor(dis_mask, dtype=torch.float32)
            # print("dis_matrix",max_dis, kernal_size, dis_tensor)
            dis_tensor = F.softmax(dis_tensor, dim=1)
        else:
            number = 0
            dis_mask=[]
            dis_mask_line=[]
            max_dis = math.sqrt(2 * (kernal_size-1)**2)
            for i in range(0,kernal_size**2):
                l1 = i//kernal_size
                c1 = i%kernal_size
                # print("x",l1,c1)
                dis_mask_line=[]
                for j in range(0,kernal_size**2):
                    l2 = j//kernal_size
                    c2 = j%kernal_size
                    dis = math.sqrt((c1-c2)*(c1-c2) + (l1-l2)*(l1-l2))
                    # print(dis)
                    dis_mask_line.append(max_dis - dis + 1)
                dis_mask.append(dis_mask_line)
            dis_tensor = torch.tensor(dis_mask, dtype=torch.float32)
            # print("dis_matrix",max_dis, kernal_size, dis_tensor)
            dis_tensor = F.softmax(dis_tensor/4.0, dim=1)
            # print("dis_matrix+soft",max_dis, kernal_size, dis_tensor)
        return dis_tensor
    
    def __init__(self, input_resolution,in_channels, up_scale=2, kernal_size=3):
        super(DESABlock, self).__init__()
        self.dis_mask_h = self.calculate_mask(kernal_size,dimension='H',scale=8)
        self.dis_mask_w = self.calculate_mask(kernal_size,dimension='W',scale=8)
        self.hidden_feature=in_channels*1
        self.DESAh = DESA(in_features=self.hidden_feature, out_features=in_channels,x_size=input_resolution, head=4, stride=(16,4), dis_mask=self.dis_mask_h, dimension='H')
        self.DESAw = DESA(in_features=self.hidden_feature, out_features=in_channels,x_size=input_resolution, head=4, stride=(4,16), dis_mask=self.dis_mask_w, dimension='W')
        self.conv = nn.Conv2d(2*in_channels, in_channels, 3, 1, 1)


    def forward(self, x):

        return self.conv(torch.cat([self.DESAh(x),self.DESAw(x)],dim=1))


class HAB(nn.Module):
    r""" This class can be HAB or the proposed DSAB in paper"DESAT", this is determined by its position in RDSG.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resolution.
        num_heads (int): Number of attention heads.
        window_size (int): Window size.
        shift_size (int): Shift size for SW-MSA.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set.
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float, optional): Stochastic depth rate. Default: 0.0
        act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
    """

    def __init__(self,
                 dim,
                 input_resolution,
                 num_heads,
                 window_size=7,
                 shift_size=0,
                 compress_ratio=3,
                 squeeze_factor=30,
                 conv_scale=0.01,
                 mlp_ratio=4.,
                 qkv_bias=True,
                 qk_scale=None,
                 drop=0.,
                 attn_drop=0.,
                 drop_path=0.,
                 act_layer=nn.GELU,
                 norm_layer=nn.LayerNorm,
                 idx=0):
        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.window_size = window_size
        self.shift_size = shift_size
        self.mlp_ratio = mlp_ratio
        self.idx=idx
        if min(self.input_resolution) <= self.window_size:
            # if window size is larger than input resolution, we don't partition windows
            self.shift_size = 0
            self.window_size = min(self.input_resolution)
        assert 0 <= self.shift_size < self.window_size, 'shift_size must in 0-window_size'

        self.norm1 = norm_layer(dim)
        self.attn = WindowAttention(
            dim,
            window_size=to_2tuple(self.window_size),
            num_heads=num_heads,
            qkv_bias=qkv_bias,
            qk_scale=qk_scale,
            attn_drop=attn_drop,
            proj_drop=drop)

        self.conv_scale = conv_scale
        

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

        if self.idx%3!=2:
            self.conv_block = CAB(num_feat=dim, compress_ratio=compress_ratio, squeeze_factor=squeeze_factor)
        else:
            self.DESA = DESABlock(input_resolution, dim , up_scale=2, kernal_size=16)

    def forward(self, x, x_size, rpi_sa, attn_mask):
        h, w = x_size
        b, _, c = x.shape
        # assert seq_len == h * w, "input feature has wrong size"

        shortcut = x
        x = self.norm1(x)
        x = x.view(b, h, w, c)

        # Conv_X
        if self.idx%3!=2:
            conv_x = self.conv_block(x.permute(0, 3, 1, 2))
            conv_x = conv_x.permute(0, 2, 3, 1).contiguous().view(b, h * w, c)
        else :
            DESA_x = self.DESA(x.permute(0, 3, 1, 2))
            DESA_x = DESA_x.permute(0, 2, 3, 1).contiguous().view(b, h * w, c)

        # cyclic shift
        if self.shift_size > 0:
            shifted_x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
            attn_mask = attn_mask
        else:
            shifted_x = x
            attn_mask = None

        # partition windows
        x_windows = window_partition(shifted_x, self.window_size)  # nw*b, window_size, window_size, c
        x_windows = x_windows.view(-1, self.window_size * self.window_size, c)  # nw*b, window_size*window_size, c

        # W-MSA/SW-MSA (to be compatible for testing on images whose shapes are the multiple of window size
        attn_windows = self.attn(x_windows, rpi=rpi_sa, mask=attn_mask)

        # merge windows
        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, c)
        shifted_x = window_reverse(attn_windows, self.window_size, h, w)  # b h' w' c

        # reverse cyclic shift
        if self.shift_size > 0:
            attn_x = torch.roll(shifted_x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))
        else:
            attn_x = shifted_x
        attn_x = attn_x.view(b, h * w, c)

        # FFN

        if self.idx%3!=2:
            x = shortcut + self.drop_path(attn_x) + conv_x * self.conv_scale
        else:
            x = shortcut + self.drop_path(attn_x) + DESA_x * self.conv_scale
        x = x + self.drop_path(self.mlp(self.norm2(x)))

        return x


class PatchMerging(nn.Module):
    r""" Patch Merging Layer.

    Args:
        input_resolution (tuple[int]): Resolution of input feature.
        dim (int): Number of input channels.
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
    """
    
    def __init__(self, input_resolution, dim, out_dim, norm_layer=nn.LayerNorm):
        super().__init__()
        self.input_resolution = input_resolution
        self.dim = dim
        self.reduction = nn.Linear(4 * dim, out_dim, bias=False)
        self.norm = norm_layer(4 * dim)

    def forward(self, x):
        """
        x: B, H*W, C
        """
        H, W = self.input_resolution
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"
        assert H % 2 == 0 and W % 2 == 0, f"x size ({H}*{W}) are not even."

        x = x.view(B, H, W, C)

        x0 = x[:, 0::2, 0::2, :]  # B H/2 W/2 C
        x1 = x[:, 1::2, 0::2, :]  # B H/2 W/2 C
        x2 = x[:, 0::2, 1::2, :]  # B H/2 W/2 C
        x3 = x[:, 1::2, 1::2, :]  # B H/2 W/2 C
        x = torch.cat([x0, x1, x2, x3], -1)  # B H/2 W/2 4*C
        x = x.view(B, -1, 4 * C)  # B H/2*W/2 4*C

        x = self.norm(x)
        x = self.reduction(x)

        return x


class OCAB(nn.Module):
    # overlapping cross-attention block

    def __init__(self, dim,
                input_resolution,
                window_size,
                overlap_ratio,
                num_heads,
                qkv_bias=True,
                qk_scale=None,
                mlp_ratio=2,
                norm_layer=nn.LayerNorm
                ):

        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.window_size = window_size
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim**-0.5
        self.overlap_win_size = int(window_size * overlap_ratio) + window_size

        self.norm1 = norm_layer(dim)
        self.qkv = nn.Linear(dim, dim * 3,  bias=qkv_bias)
        self.unfold = nn.Unfold(kernel_size=(self.overlap_win_size, self.overlap_win_size), stride=window_size, padding=(self.overlap_win_size-window_size)//2)

        # define a parameter table of relative position bias
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((window_size + self.overlap_win_size - 1) * (window_size + self.overlap_win_size - 1), num_heads))  # 2*Wh-1 * 2*Ww-1, nH

        trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

        self.proj = nn.Linear(dim,dim)

        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=nn.GELU)

    def forward(self, x, x_size, rpi):
        h, w = x_size
        b, _, c = x.shape

        shortcut = x
        x = self.norm1(x)
        x = x.view(b, h, w, c)

        qkv = self.qkv(x).reshape(b, h, w, 3, c).permute(3, 0, 4, 1, 2) # 3, b, c, h, w
        q = qkv[0].permute(0, 2, 3, 1) # b, h, w, c
        kv = torch.cat((qkv[1], qkv[2]), dim=1) # b, 2*c, h, w

        # partition windows
        q_windows = window_partition(q, self.window_size)  # nw*b, window_size, window_size, c
        q_windows = q_windows.view(-1, self.window_size * self.window_size, c)  # nw*b, window_size*window_size, c

        kv_windows = self.unfold(kv) # b, c*w*w, nw
        kv_windows = rearrange(kv_windows, 'b (nc ch owh oww) nw -> nc (b nw) (owh oww) ch', nc=2, ch=c, owh=self.overlap_win_size, oww=self.overlap_win_size).contiguous() # 2, nw*b, ow*ow, c
        k_windows, v_windows = kv_windows[0], kv_windows[1] # nw*b, ow*ow, c

        b_, nq, _ = q_windows.shape
        _, n, _ = k_windows.shape
        d = self.dim // self.num_heads
        q = q_windows.reshape(b_, nq, self.num_heads, d).permute(0, 2, 1, 3) # nw*b, nH, nq, d
        k = k_windows.reshape(b_, n, self.num_heads, d).permute(0, 2, 1, 3) # nw*b, nH, n, d
        v = v_windows.reshape(b_, n, self.num_heads, d).permute(0, 2, 1, 3) # nw*b, nH, n, d

        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))

        relative_position_bias = self.relative_position_bias_table[rpi.view(-1)].view(
            self.window_size * self.window_size, self.overlap_win_size * self.overlap_win_size, -1)  # ws*ws, wse*wse, nH
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # nH, ws*ws, wse*wse
        attn = attn + relative_position_bias.unsqueeze(0)

        attn = self.softmax(attn)
        attn_windows = (attn @ v).transpose(1, 2).reshape(b_, nq, self.dim)

        # merge windows
        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, self.dim)
        x = window_reverse(attn_windows, self.window_size, h, w)  # b h w c
        x = x.view(b, h * w, self.dim)

        x = self.proj(x) + shortcut

        x = x + self.mlp(self.norm2(x))
        # print(x.shape)#abcd
        return x


class AttenBlocks(nn.Module):
    """ A series of attention blocks for one RSAG.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resolution.
        depth (int): Number of blocks.
        num_heads (int): Number of attention heads.
        window_size (int): Local window size.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set.
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float | tuple[float], optional): Stochastic depth rate. Default: 0.0
        norm_layer (nn.Module, optional): Normalization layer. Default: nn.LayerNorm
        downsample (nn.Module | None, optional): Downsample layer at the end of the layer. Default: None
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False.
    """

    def __init__(self,
                 dim,
                 input_resolution,
                 depth,
                 num_heads,
                 window_size,
                 compress_ratio,
                 squeeze_factor,
                 conv_scale,
                 overlap_ratio,
                 mlp_ratio=4.,
                 qkv_bias=True,
                 qk_scale=None,
                 drop=0.,
                 attn_drop=0.,
                 drop_path=0.,
                 norm_layer=nn.LayerNorm,
                 downsample=None,
                 use_checkpoint=False):

        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.depth = depth
        self.use_checkpoint = use_checkpoint

        # build blocks
        self.blocks = nn.ModuleList([
            HAB(
                dim=dim,
                input_resolution=input_resolution,
                num_heads=num_heads,
                window_size=window_size,
                shift_size=0 if (i % 2 == 0) else window_size // 2,
                compress_ratio=compress_ratio,
                squeeze_factor=squeeze_factor,
                conv_scale=conv_scale,
                mlp_ratio=mlp_ratio,
                qkv_bias=qkv_bias,
                qk_scale=qk_scale,
                drop=drop,
                attn_drop=attn_drop,
                drop_path=drop_path[i] if isinstance(drop_path, list) else drop_path,
                norm_layer=norm_layer,
                idx=i) for i in range(depth)
        ])

        # OCAB
        self.overlap_attn = OCAB(
                            dim=dim,
                            input_resolution=input_resolution,
                            window_size=window_size,
                            overlap_ratio=overlap_ratio,
                            num_heads=num_heads,
                            qkv_bias=qkv_bias,
                            qk_scale=qk_scale,
                            mlp_ratio=mlp_ratio,
                            norm_layer=norm_layer
                            )
        # DESAM
        self.DESA=DESABlock(input_resolution, dim , up_scale=2, kernal_size=16)
        self.gama = nn.Parameter( torch.tensor(1.0), requires_grad=True)
        # patch merging layer
        if downsample is not None:
            self.downsample = downsample(input_resolution, dim=dim, norm_layer=norm_layer)
        else:
            self.downsample = None

    def forward(self, x, x_size, params):
        h, w = x_size
        b, _, c = x.shape

        for blk in self.blocks:
            x = blk(x, x_size, params['rpi_sa'], params['attn_mask'])

        DESA_x = self.DESA(x.view(b, h, w, c).permute(0, 3, 1, 2))
        DESA_x = DESA_x.permute(0, 2, 3, 1).contiguous().view(b, h * w, c)

        x = self.overlap_attn(x+self.gama*DESA_x , x_size, params['rpi_oca']) 

        if self.downsample is not None:
            x = self.downsample(x)
        return x


class RSAG(nn.Module):
    """This is the Residual Distance-Enhanced Strip Attention Group (RDSG).

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resolution.
        depth (int): Number of blocks.
        num_heads (int): Number of attention heads.
        window_size (int): Local window size.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set.
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float | tuple[float], optional): Stochastic depth rate. Default: 0.0
        norm_layer (nn.Module, optional): Normalization layer. Default: nn.LayerNorm
        downsample (nn.Module | None, optional): Downsample layer at the end of the layer. Default: None
        use_checkpoint (bool): Whether to use checkpointing to save memory. Default: False.
        img_size: Input image size.
        patch_size: Patch size.
        resi_connection: The convolutional block before residual connection.
    """

    def __init__(self,
                 dim,
                 input_resolution,
                 depth,
                 num_heads,
                 window_size,
                 compress_ratio,
                 squeeze_factor,
                 conv_scale,
                 overlap_ratio,
                 mlp_ratio=4.,
                 qkv_bias=True,
                 qk_scale=None,
                 drop=0.,
                 attn_drop=0.,
                 drop_path=0.,
                 norm_layer=nn.LayerNorm,
                 downsample=None,
                 use_checkpoint=False,
                 img_size=224,
                 patch_size=4,
                 resi_connection='1conv'):
        super(RSAG, self).__init__()

        self.dim = dim
        self.input_resolution = input_resolution

        self.residual_group = AttenBlocks(
            dim=dim,
            input_resolution=input_resolution,
            depth=depth,
            num_heads=num_heads,
            window_size=window_size,
            compress_ratio=compress_ratio,
            squeeze_factor=squeeze_factor,
            conv_scale=conv_scale,
            overlap_ratio=overlap_ratio,
            mlp_ratio=mlp_ratio,
            qkv_bias=qkv_bias,
            qk_scale=qk_scale,
            drop=drop,
            attn_drop=attn_drop,
            drop_path=drop_path,
            norm_layer=norm_layer,
            downsample=downsample,
            use_checkpoint=use_checkpoint)

        if resi_connection == '1conv':
            self.conv = nn.Conv2d(dim, dim, 3, 1, 1)
        elif resi_connection == 'identity':
            self.conv = nn.Identity()

        self.patch_embed = PatchEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=0, embed_dim=dim, norm_layer=None)

        self.patch_unembed = PatchUnEmbed(
            img_size=img_size, patch_size=patch_size, in_chans=0, embed_dim=dim, norm_layer=None)
        # print('dim',dim)
        self.DESA=DESABlock(input_resolution, dim , up_scale=2, kernal_size=16)

    def forward(self, x, x_size, params):
        y=self.patch_unembed(self.residual_group(x, x_size, params), x_size)
        # print("y.shape",y.shape)
        # print("self.DESA(y).shape",self.DESA(y).shape)
        # fea=torch.cat([y,self.DESA(self.patch_unembed(x, x_size))],dim=1)
        # print("fea",fea.shape)
        # print("conv",self.conv(fea).shape)
        return self.patch_embed(self.conv(y)) + x 


class PatchEmbed(nn.Module):
    r""" Image to Patch Embedding

    Args:
        img_size (int): Image size.  Default: 224.
        patch_size (int): Patch token size. Default: 4.
        in_chans (int): Number of input image channels. Default: 3.
        embed_dim (int): Number of linear projection output channels. Default: 96.
        norm_layer (nn.Module, optional): Normalization layer. Default: None
    """

    def __init__(self, img_size=224, patch_size=4, in_chans=3, embed_dim=96, norm_layer=None):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        patches_resolution = [img_size[0] // patch_size[0], img_size[1] // patch_size[1]]
        self.img_size = img_size
        self.patch_size = patch_size
        self.patches_resolution = patches_resolution
        self.num_patches = patches_resolution[0] * patches_resolution[1]

        self.in_chans = in_chans
        self.embed_dim = embed_dim

        if norm_layer is not None:
            self.norm = norm_layer(embed_dim)
        else:
            self.norm = None

    def forward(self, x):
        x = x.flatten(2).transpose(1, 2)  # b Ph*Pw c
        if self.norm is not None:
            x = self.norm(x)
        return x


class PatchUnEmbed(nn.Module):
    r""" Image to Patch Unembedding

    Args:
        img_size (int): Image size.  Default: 224.
        patch_size (int): Patch token size. Default: 4.
        in_chans (int): Number of input image channels. Default: 3.
        embed_dim (int): Number of linear projection output channels. Default: 96.
        norm_layer (nn.Module, optional): Normalization layer. Default: None
    """

    def __init__(self, img_size=224, patch_size=4, in_chans=3, embed_dim=96, norm_layer=None):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        patches_resolution = [img_size[0] // patch_size[0], img_size[1] // patch_size[1]]
        self.img_size = img_size
        self.patch_size = patch_size
        self.patches_resolution = patches_resolution
        self.num_patches = patches_resolution[0] * patches_resolution[1]

        self.in_chans = in_chans
        self.embed_dim = embed_dim

    def forward(self, x, x_size):
        x = x.transpose(1, 2).contiguous().view(x.shape[0], self.embed_dim, x_size[0], x_size[1])  # b Ph*Pw c
        return x

class Upsample(nn.Sequential):
    """the Pixel Shuffle Upsample module.

    Args:
        scale (int): Scale factor. Supported scales: 2^n and 3.
        num_feat (int): Channel number of intermediate features.
    """

    def __init__(self, scale, num_feat):
        m = []
        if (scale & (scale - 1)) == 0:  # scale = 2^n
            for _ in range(int(math.log(scale, 2))):
                m.append(nn.Conv2d(num_feat, 4 * num_feat, 3, 1, 1))
                m.append(nn.PixelShuffle(2))
        elif scale == 3:
            m.append(nn.Conv2d(num_feat, 9 * num_feat, 3, 1, 1))
            m.append(nn.PixelShuffle(3))
        else:
            raise ValueError(f'scale {scale} is not supported. ' 'Supported scales: 2^n and 3.')
        super(Upsample, self).__init__(*m)


class mish(nn.Module):
    def __init__(self, ):
        super(mish, self).__init__()
        self.activated = True

    def forward(self, x):
        if self.activated:
            x = x * (torch.tanh(F.softplus(x)))
        return x

class AttentionUP(nn.Module):# the attention branch of AEUB in paper"DESAT"
    def __init__(self,in_features,out_features,head=1,stride=2, up_scale=2, dis_maskup=[], alpha=0.2):
        super(AttentionUP,self).__init__()
        self.in_features=in_features
        self.hid_features=out_features*3
        self.head=head
        self.stride=stride
        self.up_scale=up_scale
        self.kernal_size = stride*up_scale
        self.dis_mask=dis_maskup.view(1,self.kernal_size**2,self.kernal_size**2)
        self.trans=nn.Conv2d(in_channels=self.in_features,out_channels=self.hid_features,kernel_size=3,stride=1,padding=1,bias=False)
        self.pad=nn.Unfold(kernel_size=self.kernal_size,padding=(self.kernal_size)//4,stride=self.stride)
        self.fold=nn.Fold(output_size=(512,512),kernel_size=self.kernal_size,padding=0,stride=self.stride*2)
        self.drop=nn.Dropout(0.0)
        self.leakyrelu=nn.LeakyReLU(alpha)
        self.norm2=nn.LayerNorm(out_features)
        self.mlp = Mlp(in_features=out_features, hidden_features=out_features)
        self.outconv=nn.Conv2d(in_channels=out_features,out_channels=self.in_features,kernel_size=3,stride=1,padding=1,bias=False)
    
    def forward(self, x):
        self.dis_mask=self.dis_mask.to(x.device)
        x=self.trans(x)
        q,k,v=torch.chunk(x, 3, dim=1)

        b,c,h,w=q.shape
        q=q.reshape(b,self.head,-1,h,w)
        k=k.reshape(b,self.head,-1,h,w)
        v=v.reshape(b,self.head,-1,h,w)

        q=q.reshape(b*self.head,-1,h,w)
        q=self.pad(q)

        q=q.view(b,self.head,-1,self.kernal_size**2 ,h//self.stride,w//self.stride).permute(0,1,4,5,3,2).contiguous()#b,head,h/2,w/2,16,c//head

        k=k.reshape(b*self.head,-1,h,w)
        k=self.pad(k)
        k=k.view(b,self.head,-1,self.kernal_size**2,h//self.stride,w//self.stride).permute(0,1,4,5,2,3).contiguous()#b,head,h/2,w/2,c//head,16
        
        v=v.reshape(b*self.head,-1,h,w)
        v=self.pad(v)
        v=v.view(b,self.head,-1,self.kernal_size**2,h//self.stride,w//self.stride).permute(0,1,4,5,3,2).contiguous()#b,head,h/2,w/2,16,c//head



        att=q@k
        att=att/math.sqrt(c//self.head)
        att=att.view(-1, self.kernal_size**2, self.kernal_size**2)
        att=att * self.dis_mask
        att=att.view(b, self.head, h//self.stride, w//self.stride, self.kernal_size**2, self.kernal_size**2)
        att=F.softmax(att,dim=-1)
        
        att=self.drop(att)
        
        result=att@v
        
        result=result.permute(0,1,5,4,2,3).contiguous()
        result=result.view(b,-1,(h//self.stride)*(w//self.stride))
        result=self.fold(result)

        
        return result
    
class GRAPHUP(nn.Module): #the proposed AEUB in paper"DESAT"
    def __init__(self, in_features,out_features,head=1,stride=2,up_scale=2,dis_maskup=[]):
        super(GRAPHUP, self).__init__()

        self.beta = torch.zeros(1)
        self.AttentionUP = nn.Sequential( 
            AttentionUP(in_features,out_features,head, stride, dis_maskup = dis_maskup), 
		)
        self.pixelup = nn.Sequential(
            nn.Conv2d(in_features, out_features * up_scale ** 2, kernel_size=3, padding=1),
            nn.PixelShuffle(up_scale),
        )

    def forward(self, x): 
        return self.AttentionUP(x)

class Fusion(nn.Module):
    r""" Transformer fusion block.

    Args:
        dim (int): Number of input channels.
        input_resolution (tuple[int]): Input resulotion.
        num_heads (int): Number of attention heads.
        window_size (int): Window size.
        shift_size (int): Shift size for SW-MSA.
        mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
        qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None, optional): Override default qk scale of head_dim ** -0.5 if set.
        drop (float, optional): Dropout rate. Default: 0.0
        attn_drop (float, optional): Attention dropout rate. Default: 0.0
        drop_path (float, optional): Stochastic depth rate. Default: 0.0
        act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
        norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
    """

    def __init__(self, dim, input_resolution, num_heads, window_size=7, shift_size=0,
                 mlp_ratio=4., qkv_bias=True, qk_scale=None, drop=0., attn_drop=0., drop_path=0.,
                 act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.window_size = window_size
        self.shift_size = shift_size
        self.mlp_ratio = mlp_ratio
        if min(self.input_resolution) <= self.window_size:
            # if window size is larger than input resolution, we don't partition windows
            self.shift_size = 0
            self.window_size = min(self.input_resolution)
        assert 0 <= self.shift_size < self.window_size, "shift_size must in 0-window_size"

        self.norm1 = norm_layer(dim)
        self.attn = WindowFusion(
            dim, window_size=to_2tuple(self.window_size), num_heads=num_heads,
            qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop)

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)

        self.norm3 = norm_layer(dim*2)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

        if self.shift_size > 0:
            attn_mask = self.calculate_mask(self.input_resolution)
        else:
            attn_mask = None

        self.register_buffer("attn_mask", attn_mask)

    def calculate_mask(self, x_size):
        # calculate attention mask for SW-MSA
        H, W = x_size
        img_mask = torch.zeros((1, H, W, 1))  # 1 H W 1
        h_slices = (slice(0, -self.window_size),
                    slice(-self.window_size, -self.shift_size),
                    slice(-self.shift_size, None))
        w_slices = (slice(0, -self.window_size),
                    slice(-self.window_size, -self.shift_size),
                    slice(-self.shift_size, None))
        cnt = 0
        for h in h_slices:
            for w in w_slices:
                img_mask[:, h, w, :] = cnt
                cnt += 1

        mask_windows = window_partition(img_mask, self.window_size)  # nW, window_size, window_size, 1
        mask_windows = mask_windows.view(-1, self.window_size * self.window_size)
        attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
        attn_mask = attn_mask.masked_fill(attn_mask != 0, float(-100.0)).masked_fill(attn_mask == 0, float(0.0))

        return attn_mask

    def forward(self, x, y, x_size):
        H, W = x_size
        # print(x.shape)
        B, L, C = x.shape
        # assert L == H * W, "input feature has wrong size"

        shortcut = x
        x = self.norm1(x)
        x = x.view(B, H, W, C)

        y = self.norm3(y)
        y = y.view(B, H, W, 2*C)

        # cyclic shift
        if self.shift_size > 0:
            shifted_x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
            shifted_y = torch.roll(y, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
        else:
            shifted_x = x
            shifted_y = y

        # partition windows
        x_windows = window_partition(shifted_x, self.window_size)  # nW*B, window_size, window_size, C
        x_windows = x_windows.view(-1, self.window_size * self.window_size, C)  # nW*B, window_size*window_size, C
        y_windows = window_partition(shifted_y, self.window_size)  # nW*B, window_size, window_size, C
        y_windows = y_windows.view(-1, self.window_size * self.window_size, 2*C)  # nW*B, window_size*window_size, C
        # W-MSA/SW-MSA (to be compatible for testing on images whose shapes are the multiple of window size
        if self.input_resolution == x_size:
            attn_windows = self.attn(x_windows,y_windows,mask=self.attn_mask)  # nW*B, window_size*window_size, C
        else:
            attn_windows = self.attn(x_windows,y_windows,mask=self.calculate_mask(x_size).to(x.device))

        # merge windows
        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, C)
        shifted_x = window_reverse(attn_windows,self.window_size, H, W)  # B H' W' C

        # reverse cyclic shift
        if self.shift_size > 0:
            x = torch.roll(shifted_x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))
        else:
            x = shifted_x
        x = x.view(B, H * W, C)

        # FFN
        x = self.drop_path(x)
        x = x + self.drop_path(self.mlp(x))

        return x

    def extra_repr(self) -> str:
        return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
               f"window_size={self.window_size}, shift_size={self.shift_size}, mlp_ratio={self.mlp_ratio}"

    def flops(self):
        flops = 0
        H, W = self.input_resolution
        # norm1
        flops += self.dim * H * W
        # W-MSA/SW-MSA
        nW = H * W / self.window_size / self.window_size
        flops += nW * self.attn.flops(self.window_size * self.window_size)
        # mlp
        flops += 2 * H * W * self.dim * self.dim * self.mlp_ratio
        # norm2
        flops += self.dim * H * W
        return flops

class AttentionEnhancedUpsampleBlock(nn.Module): #the AEUB in paper"DESAT"
    def calculate_mask(self, kernal_size):
        # calculate attention mask for SW-MSA in different patch resolution 
        number = 0
        dis_mask=[]
        dis_mask_line=[]
        max_dis = math.sqrt(2 * (kernal_size-1)**2)
        for i in range(0,kernal_size**2):
            l1 = i//kernal_size
            c1 = i%kernal_size
            # print("x",l1,c1)
            dis_mask_line=[]
            for j in range(0,kernal_size**2):
                l2 = j//kernal_size
                c2 = j%kernal_size
                dis = math.sqrt((c1-c2)*(c1-c2) + (l1-l2)*(l1-l2))
                # print(dis)
                dis_mask_line.append(max_dis - dis + 1)
            dis_mask.append(dis_mask_line)
        dis_tensor = torch.tensor(dis_mask, dtype=torch.float32)
        # print("dis_matrix",max_dis, kernal_size, dis_tensor)
        dis_tensor = F.softmax(dis_tensor/math.sqrt(kernal_size), dim=1)
        # print("dis_matrix+soft",max_dis, kernal_size, dis_tensor)
        return dis_tensor
    
    def __init__(self, in_channels, up_scale=2, kernal_size=3):
        super(AttentionEnhancedUpsampleBlock, self).__init__()
        self.conv = nn.Conv2d((in_channels)*2, in_channels, kernel_size=3, padding=1)
        self.dis_mask = self.calculate_mask(kernal_size)
        self.hidden_feature=in_channels*1

        self.dis_maskup = self.calculate_mask(4*up_scale)
        self.attentionup8 = nn.Sequential( 
            AttentionUP(in_features=in_channels,out_features=self.hidden_feature, head=4, stride=4, dis_maskup = self.dis_maskup), 
		)
        self.gama = nn.Parameter( torch.tensor(0.01), requires_grad=True)
        self.pixelup = nn.Sequential(
            nn.Conv2d(in_channels, in_channels * up_scale ** 2, kernel_size=3, padding=1),
            nn.PixelShuffle(up_scale),
        )
        self.patch_embed = PatchEmbed(
            img_size=(512,512), patch_size=2, in_chans=64, embed_dim=64,
            norm_layer=None)
        self.patch_embed3 = PatchEmbed(
            img_size=(512,512), patch_size=2, in_chans=64*2, embed_dim=64*2,
            norm_layer=None)
        fusion_window_size=8
        fusion_depth=1
        self.fusions = nn.ModuleList([
            Fusion(dim=in_channels, input_resolution=(512,512),
                                 num_heads=2, window_size=fusion_window_size,
                                 shift_size=0 if (i % 2 == 0) else fusion_window_size // 2,
                                 mlp_ratio=2.,
                                 qkv_bias=True, qk_scale=None,
                                 norm_layer=nn.LayerNorm)
            for i in range(fusion_depth)])
        
        self.patch_unembed = PatchUnEmbed(
            img_size=(512,512), patch_size=2, in_chans=64, embed_dim=64,
            norm_layer=nn.LayerNorm)
        
        self.norm = nn.LayerNorm(64)
        

    def forward(self, x):
        x_size = (x.shape[2]*2, x.shape[3]*2)
        x_pixel=self.pixelup(x)
        shortcut=x_pixel
        x_attn=torch.cat([self.attentionup8(x),x_pixel],dim=1)
        x_pixel = self.patch_embed(x_pixel)
        x_attn = self.patch_embed3(x_attn)
        for fusion in self.fusions:
            x_pixel=fusion(x_pixel,x_attn,x_size)
        x_pixel = self.patch_unembed(x_pixel, x_size)
        return 0.01*x_pixel+shortcut


def window_partition(x, window_size):
    """
    Args:
        x: (b, h, w, c)
        window_size (int): window size

    Returns:
        windows: (num_windows*b, window_size, window_size, c)
    """
    b, h, w, c = x.shape
    x = x.view(b, h // window_size, window_size, w // window_size, window_size, c)
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, c)
    return windows


def window_reverse(windows, window_size, h, w):
    """
    Args:
        windows: (num_windows*b, window_size, window_size, c)
        window_size (int): Window size
        h (int): Height of image
        w (int): Width of image

    Returns:
        x: (b, h, w, c)
    """
    b = int(windows.shape[0] / (h * w / window_size / window_size))
    x = windows.view(b, h // window_size, w // window_size, window_size, window_size, -1)
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(b, h, w, -1)
    return x



class DESAT(nn.Module):
    def __init__(self,
                 img_size=256,
                 window_size=8,
                 patch_size=1,
                 in_chans=8,
                 embed_dim=96,
                 up_feat=64,
                 depths=(6,6,6,6), 
                 num_heads=(6,6,6,6),
                 compress_ratio=3,
                 squeeze_factor=30,
                 conv_scale=0.01,
                 overlap_ratio=0.5,
                 mlp_ratio=2.,
                 qkv_bias=True,
                 qk_scale=None,
                 drop_rate=0.,
                 attn_drop_rate=0.,
                 drop_path_rate=0.1,
                 norm_layer=nn.LayerNorm,
                 ape=False,
                 patch_norm=True,
                 use_checkpoint=False,
                 down_scale=1,
                 out_chanal=4,
                 upscale=2,
                 img_range=1.,
                 upsampler='aeub',
                 resi_connection='1conv'):
        super(DESAT, self).__init__()
        # relative position index

        # num_in_ch = in_chans
        # num_out_ch = in_chans
        num_feat = up_feat
        self.img_range = img_range
        self.upscale = upscale
        self.upsampler = upsampler

        self.down_scale=down_scale
        self.window_size = window_size
        self.shift_size = window_size // 2
        self.overlap_ratio = overlap_ratio
        self.attn_mask = {}
        relative_position_index_SA = self.calculate_rpi_sa()
        relative_position_index_OCA = self.calculate_rpi_oca()
        self.register_buffer('relative_position_index_SA', relative_position_index_SA)
        self.register_buffer('relative_position_index_OCA', relative_position_index_OCA)

        x_size = (img_size, img_size)
        self.params=[]
        self.attn_mask = self.calculate_mask(x_size)
        for i in range(0,4):
            self.params.append({'attn_mask': self.attn_mask[i], 'rpi_sa': self.relative_position_index_SA, 'rpi_oca': self.relative_position_index_OCA})
        
        # ------------------------- 1, shallow feature extraction ------------------------- #   
        self.conv_first = nn.Conv2d(in_chans, embed_dim, 3, 1, 1)

        # ------------------------- 2, deep feature extraction ------------------------- #
        self.num_layers = len(depths)
        self.embed_dim = embed_dim
        self.ape = ape
        self.patch_norm = patch_norm
        self.num_features = embed_dim
        self.mlp_ratio = mlp_ratio
        self.patch_embed = PatchEmbed(
            img_size=img_size,
            patch_size=patch_size,
            in_chans=embed_dim,
            embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)
        num_patches = self.patch_embed.num_patches
        patches_resolution = self.patch_embed.patches_resolution
        self.patches_resolution = patches_resolution

        self.patch_unembed = PatchUnEmbed(
            img_size=img_size,
            patch_size=patch_size,
            in_chans=embed_dim,
            embed_dim=embed_dim,
            norm_layer=norm_layer if self.patch_norm else None)

        # absolute position embedding
        if self.ape:
            self.absolute_pos_embed = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
            trunc_normal_(self.absolute_pos_embed, std=.02)

        self.pos_drop = nn.Dropout(p=drop_rate)

        # stochastic depth
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule

        # build Residual Distacne-Enhanced Strip Attention Groups (RDSG)
        self.layers = nn.ModuleList()
        for i_layer in range(self.num_layers):
            layer = RSAG(
                dim=embed_dim,
                input_resolution=(patches_resolution[0], patches_resolution[1]),
                depth=depths[i_layer],
                num_heads=num_heads[i_layer],
                window_size=window_size,
                compress_ratio=compress_ratio,
                squeeze_factor=squeeze_factor,
                conv_scale=conv_scale,
                overlap_ratio=overlap_ratio,
                mlp_ratio=self.mlp_ratio,
                qkv_bias=qkv_bias,
                qk_scale=qk_scale,
                drop=drop_rate,
                attn_drop=attn_drop_rate,
                drop_path=dpr[sum(depths[:i_layer]):sum(depths[:i_layer + 1])],  # no impact on SR results
                norm_layer=norm_layer,
                downsample=None,
                use_checkpoint=use_checkpoint,
                img_size=img_size,
                patch_size=patch_size,
                resi_connection=resi_connection)
            self.layers.append(layer)
        self.norm = norm_layer(self.num_features)


        if resi_connection == '1conv':
            self.conv_after_body = nn.Conv2d(embed_dim, embed_dim, 3, 1, 1)
        elif resi_connection == 'identity':
            self.conv_after_body = nn.Identity()
        

        # ------------------------- 3, high quality image reconstruction ------------------------- #
        if self.upsampler == 'pixelshuffle':
            # for classical SR
            self.conv_before_upsample = nn.Sequential(
                nn.Conv2d(embed_dim, num_feat, 3, 1, 1), nn.LeakyReLU(inplace=True))
            self.upsample = Upsample(self.upscale,num_feat)
            self.conv_last = nn.Conv2d(num_feat, out_chanal, 3, 1, 1)
        elif self.upsampler == 'aeub':
            self.conv_before_upsample = nn.Sequential(
                nn.Conv2d(embed_dim, num_feat, 3, 1, 1), nn.LeakyReLU(inplace=True))
            self.upsample = AttentionEnhancedUpsampleBlock(num_feat,self.upscale,kernal_size=3)
            self.conv_last = nn.Conv2d(num_feat, out_chanal, 3, 1, 1)
        
        self.apply(self._init_weights)


    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def calculate_rpi_sa(self):
        # calculate relative position index for SA
        coords_h = torch.arange(self.window_size)
        coords_w = torch.arange(self.window_size)
        coords = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, Wh, Ww
        coords_flatten = torch.flatten(coords, 1)  # 2, Wh*Ww
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # 2, Wh*Ww, Wh*Ww
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # Wh*Ww, Wh*Ww, 2
        relative_coords[:, :, 0] += self.window_size - 1  # shift to start from 0
        relative_coords[:, :, 1] += self.window_size - 1
        relative_coords[:, :, 0] *= 2 * self.window_size - 1
        relative_position_index = relative_coords.sum(-1)  # Wh*Ww, Wh*Ww
        return relative_position_index

    def calculate_rpi_oca(self):
        # calculate relative position index for OCA
        window_size_ori = self.window_size
        window_size_ext = self.window_size + int(self.overlap_ratio * self.window_size)

        coords_h = torch.arange(window_size_ori)
        coords_w = torch.arange(window_size_ori)
        coords_ori = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, ws, ws
        coords_ori_flatten = torch.flatten(coords_ori, 1)  # 2, ws*ws

        coords_h = torch.arange(window_size_ext)
        coords_w = torch.arange(window_size_ext)
        coords_ext = torch.stack(torch.meshgrid([coords_h, coords_w]))  # 2, wse, wse
        coords_ext_flatten = torch.flatten(coords_ext, 1)  # 2, wse*wse

        relative_coords = coords_ext_flatten[:, None, :] - coords_ori_flatten[:, :, None]   # 2, ws*ws, wse*wse

        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # ws*ws, wse*wse, 2
        relative_coords[:, :, 0] += window_size_ori - window_size_ext + 1  # shift to start from 0
        relative_coords[:, :, 1] += window_size_ori - window_size_ext + 1

        relative_coords[:, :, 0] *= window_size_ori + window_size_ext - 1
        relative_position_index = relative_coords.sum(-1)
        return relative_position_index

    def calculate_mask(self, x_size):
        # calculate attention mask for SW-MSA in different patch resolution 
        attn_mask=[]
        H, W = x_size 
        H = H // self.down_scale
        W = W // self.down_scale
        for i in range(0,4):
            img_mask = torch.zeros((1, H, W, 1))  # 1 H W 1
            h_slices = (slice(0, -self.window_size), slice(-self.window_size,
                                                        -self.shift_size), slice(-self.shift_size, None))
            w_slices = (slice(0, -self.window_size), slice(-self.window_size,
                                                        -self.shift_size), slice(-self.shift_size, None))
            cnt = 0
            for h in h_slices:
                for w in w_slices:
                    img_mask[:, h, w, :] = cnt
                    cnt += 1

            mask_windows = window_partition(img_mask, self.window_size)  # nw, window_size, window_size, 1
            mask_windows = mask_windows.view(-1, self.window_size * self.window_size)
            attn_mask.append(mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2))
            attn_mask[i] = attn_mask[i].masked_fill(attn_mask[i] != 0, float(-100.0)).masked_fill(attn_mask[i] == 0, float(0.0))
            H = H // 2
            W = W // 2

        return attn_mask

    @torch.jit.ignore
    def no_weight_decay(self):
        return {'absolute_pos_embed'}

    @torch.jit.ignore
    def no_weight_decay_keywords(self):
        return {'relative_position_bias_table'}
    

    def forward_features(self, x):
        x_size = (x.shape[2], x.shape[3])

        # Calculate attention mask and relative position index in advance to speed up inference. 
        # The original code is very time-cosuming for large window size.
        # attn_mask = self.calculate_mask(x_size).to(x.device)
        params = self.params[0]
        params['attn_mask'] = params['attn_mask'].to(x.device)
        x = self.patch_embed(x)
        if self.ape:
            x = x + self.absolute_pos_embed
        x = self.pos_drop(x)

        for layer in self.layers:
            x = layer(x, x_size, params)

        x = self.norm(x)  # b seq_len c
        x = self.patch_unembed(x, x_size)

        return x

    def forward(self, x):


        # # Calculate attention mask and relative position index in advance to speed up inference. 
        # # The original code is very time-consuming for large window size.

        x_size = (x.shape[2], x.shape[3])
        x = self.conv_first(x)
        x = self.conv_after_body(self.forward_features(x)) + x

        output=self.conv_before_upsample(x)
        output= self.conv_last(self.upsample(output))

        return output
    

if __name__ == '__main__':
    input = torch.rand(1, 8, 256, 256).cuda()  # B C H W
    model = DESAT().cuda()
    flops, params = profile(model, inputs=(input,))
    print("Param: {} M".format(params/1e6))
    print("FLOPs: {} G".format(flops/1e9))
